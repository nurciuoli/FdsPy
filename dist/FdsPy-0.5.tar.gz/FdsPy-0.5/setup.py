from setuptools import setup, find_packages

setup(
    name="FdsPy",
    version="0.5",
    description="A library of common python scripts",
    packages=find_packages(),
)