from setuptools import setup, find_packages

setup(
    name="FdsPy",
    version="0.7",
    description="A library of common python scripts",
    packages=find_packages(),
)