from setuptools import setup, find_packages

setup(
    name="FdsPy",
    version="0.2",
    description="A library of common python scripts",
    packages=["pa","fpe","spar","misc","qe"],
)